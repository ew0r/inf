#i=int(input())
#to jest wychaszowane bo tego nie potrzebujemy 
text='Polska'
liczbowa=67
text+=' jest piekna'
lista=list(text.split())


#lista.append('to kraj')


print(lista)