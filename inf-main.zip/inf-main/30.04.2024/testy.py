i='123456789'

print(i[::2]) #cały string co 2 miejsce

print(i[3:6]) #od 3 włącznie do 6 wyłącznie(liczymy od 0)

print(i[3:6:4]) #przeskakuje na początek

a='abcdefgh'

print(a[1:4])