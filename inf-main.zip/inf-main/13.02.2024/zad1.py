x= int(input())
y= str(x)
count=0

for i in y:
    if i=='5':
        count+=1
print(count)