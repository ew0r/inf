x=int(input())
y=list(str(x))
N2='1'.join(y) 