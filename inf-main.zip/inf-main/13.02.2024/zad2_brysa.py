x=(input())
a=0
li=[]

for z in x:
    if number.count(z)> 2:
        
            a+=1
        else:
            li.append(z)
print(li)            


