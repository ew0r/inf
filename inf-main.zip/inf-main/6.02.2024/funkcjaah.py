x=10
y=67
def liczba(x):
    x=x//2
    return x,

if x==10:
    liczba(y)
print(liczba(4))



# A Python program to return multiple 
# values from a method using list 

# This function returns a list 
def fun(): 
	str = "geeksforgeeks"
	x = 20
	return [str, x]; 

# Driver code to test above method 
list = fun() 
print(list) 

