n=int(input())
cf=[1,1,3]
a=1

while cf[-1]<100000:
    l=cf[-1] + cf[-2]
    for a in list(str(n)):
        x=str(cf[-1])
        for b in list():
            if a==b:
               cf.append(l)

print(cf)

