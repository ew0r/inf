#UŻ podaje liczbę sprawdź czy jest to palindrom
e=(input())
if e==e[::-1]:
    print('TAK')
else:
    print('NIE')