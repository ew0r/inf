plik= open('wyniki.txt','w')
s=input()
type=type(s)
if type() =='str':
    print('str')
plik.close()        
    

