lst=[1,2,3]
s=[str(i) for i in lst]
print("".join(s))